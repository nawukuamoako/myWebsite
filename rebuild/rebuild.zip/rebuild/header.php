
<header>
    <div>
        <a href="nathan.php"><img class="logo" src="images/nathan-logo.png" alt="Nathan Awuku Amoako"></a>
        
    </div>
    <a href="javascript:void(0);" class="icon main-menu" onclick="toggleMenu()" > <i class="fa fa-bars"></i></a>
    <menu id="nav-menu">
        <?php print"
        <li><a href='#' onclick='toggleTheme()'><i class='fa fa-adjust'><span style='margin-left: 5px;'>Theme</span></i></a></li>
        <li><a href='about.php'>About</a></li>
        <li><a href='skills.php'>Skills</a></li>
        <li><a href=$projects>Projects</a></li>
        <li ><a href='#'><i class='fa fa-file-pdf-o'><span style='margin-left: 5px;'>Resume</span></i></a></li>
        <li><a href=$contact>Contact</a></li>";
        ?>
    </menu>
</header>