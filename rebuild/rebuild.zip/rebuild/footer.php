<footer>
    <div>
        Copyright <span> <i class="fa fa-copyright"></i> </span> Nathan Awuku Amoako 2024
        <br>
        <a href="#top"><span><i class="fa fa-arrow-up"> Back to top</i></span></a>
    </div>
</footer>