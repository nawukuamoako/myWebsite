
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Nathan Awuku Amoako">
    <meta name="keywords" content="Computer Science, ISU">
    
    <?php print"<title>$word </title>";?>
    <link rel="icon" type="image/x-icon" href="images/nathan-logo.jpeg">
    <?php print"<link rel='stylesheet' href= $css >";?>
    <?php print "<link rel='stylesheet' href= $style>";?>
</head>